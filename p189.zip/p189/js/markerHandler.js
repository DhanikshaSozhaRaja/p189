AFRAME.registerComponent('markerhandler', {
    init: async function(){
        this.el.addEventListener("markerFound", ()=>{
            console.log("marker is found")
            this.handleMarkerFound()})
        this.el.addEventListener("markerLost", ()=>{this.handleMarkerLost()})
    },
    handleMarkerFound: function(){
        var buttonDiv = document.getElementById("button-div")
        buttonDiv.style.display = "flex"
        var ratingButton = document.getElementById("rating-button")
        var orderButton = document.getElementById("order-button")
        ratingButton.addEventListener("click", function(){
            swal({
                icon: 'warning',
                title: 'Rate the Dish',
                text: 'Thanks for the Rating:)'
            })
        })
        orderButton.addEventListener("click", function(){
            swal({
                icon: 'https://i.imgur.com/4NZ6uLY.jpg',
                title: 'Thanks for your order!',
                text: 'Your Order will be served soon...'
            })
        })
    },
    handleMarkerLost: function(){
        var buttonDiv = document.getElementById("button-div")
        buttonDiv.style.display = "none"
    }
})